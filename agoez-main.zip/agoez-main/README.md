<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?color=%2336BCF7&center=true&vCenter=true&lines=WINGS+MULTIPORT+ONLY" />
</p>

# UPDATE UNTUK DEBIAN
apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot

# UPDATE UNTUK UBUNTU
apt update && apt upgrade -y && update-grub && sleep 2 && reboot
# INSTALL
<pre><code>apt update && apt upgrade -y && update-grub && sleep 2 && sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt upgrade && apt install -y bzip2 gzip coreutils screen curl unzip && wget -q https://raw.githubusercontent.com/wingshope/agoez/main/setup.sh && chmod +x setup.sh && ./setup.sh</code></pre>

## HARGA AUTOSCRIPT
### _1 Bulan 10k_
### _Lifetime 2x ganti ip 40K_
### _Source script 250k_

## Silahkan Hubungi
### https://wa.me/6282261333421

## ⏩ AUTOSCRIPT WEBSOCKET MULTIPORT 443 DETAILS ⏪
### Support Vmess Multipath <br> 
[ SSH & XRAY SERVICES ] <br>
<br>
✅ OpenSSH : 22 <br>
✅ Dropbear : 109,143 <br>
✅ SSH SSL Websocket : 443 <br>
✅ Vmess WS TLS : 443 <br>
✅ Vless WS TLS : 443 <br>
✅ Trojan WS TLS : 443 <br>
✅ Shadowsocks WS TLS : 443 <br>
✅ Vmess gRPC : 443 <br>
✅ Vless gRPC : 443 <br>
✅ Trojan gRPC : 443 <br>
✅ Shadowsocks gRPC : 443 <br>
✅ SSH Websocket : 80 <br>
✅ Vmess WS none TLS : 80 <br>
✅ Vless WS none TLS : 80 <br>
✅ Stunnel5 : 447,777 <br>
✅ UDP&DNS : 1-65000 <br>

![Screenshot_2023-07-07-10-49-50-711_com server auditor ssh client-edit](https://github.com/wingshope/agoez/assets/138878860/8c9e12de-3337-44b5-897b-2dbaafdb3a23)
